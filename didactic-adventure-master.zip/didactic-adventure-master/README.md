# didactic-adventure
